package com.vtschool2526;

import com.vtschool2526.model.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.List;

public class App {
    static void main(String[] args) {
        try {
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            Session session = sessionFactory.openSession();

            if (session != null) {
                System.out.println("Session successfully opened!");

                Query<Student> query = session.createQuery("from Student", Student.class);
                List<Student> students = query.list();

                for (Student student : students) {
                    System.out.printf(" %s %s (%s)%n",
                            student.getFirstname(),
                            student.getLastname(),
                            student.getIdcard());
                }

                session.close();
                sessionFactory.close();
            } else {
                System.out.println("Error opening session.");
            }

        } catch (Exception e) {
            System.out.println("Error connecting with Hibernate.");
        }
    }
}
