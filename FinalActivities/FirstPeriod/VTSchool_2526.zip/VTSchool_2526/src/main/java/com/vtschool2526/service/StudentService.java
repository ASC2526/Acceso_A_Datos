package com.vtschool2526.service;

import com.vtschool2526.model.Student;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public class StudentService {

    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{0,12}$");

    public static boolean importStudents(List<Student> students) {
        boolean ok = true;
        Set<String> ids = new HashSet<>();
        StringBuilder errors = new StringBuilder();

        for (int i = 0; i < students.size(); i++) {
            Student s = students.get(i);
            String id = s.getIdcard();
            if (id == null || id.isBlank()) {
                errors.append(String.format("Student #%d: missing idcard.%n", i+1));
                ok = false;
            } else {
                if (ids.contains(id)) {
                    errors.append(String.format("Student #%d: duplicated idcard in file -> %s%n", i+1, id));
                    ok = false;
                }
                ids.add(id);
            }

            String phone = s.getPhone() == null ? "" : s.getPhone();
            if (!PHONE_PATTERN.matcher(phone).matches()) {
                errors.append(String.format("Student %s: invalid phone format -> '%s'%n", id, phone));
                ok = false;
            }

            String email = s.getEmail();
            if (email != null && !email.isBlank()) {
                if (!email.contains("@")) {
                    errors.append(String.format("Student %s: invalid email -> '%s'%n", id, email));
                    ok = false;
                }
            }
        }

        if (!ok) {
            System.err.println("Errors found:");
            System.err.println(errors.toString());
            return false;
        }

        System.out.println("Parsed students...to be imported...:");
        students.forEach(st -> System.out.printf(" - %s %s (%s) phone=%s email=%s%n",
                st.getFirstname(), st.getLastname(), st.getIdcard(),
                st.getPhone(), st.getEmail()));
        return true;
    }
}
